
function startGame() {
  alert("Let's go! سيتم البدء في اللعبة...");
  // سيتم تطويرها لاحقًا
}
